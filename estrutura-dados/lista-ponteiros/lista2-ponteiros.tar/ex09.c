/*[Ex09]. Escreva uma função recursiva para imprimir uma string.
    void imprime_string(char* s)
*/
#include<stdio.h>
#include"./lib/pointer.h"

int main( int argc, char** argv )
{
		char string[] = "testing";

		printString( string );

		return 0;
}
